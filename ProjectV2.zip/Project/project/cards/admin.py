from django.contrib import admin

# Register your models here.
from .models import Card, Task

@admin.register(Card)
class CardAdmin(admin.ModelAdmin):
    list_display = ['title','description','status']

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ['description', 'done', 'card']