from django.urls import path, include
from rest_framework.routers import SimpleRouter

from .views import (
   CardViewSet,
   CardViewSetD

)


urlpatterns = [
   path('cards/',CardViewSet.as_view(),name='cards'),
   path('cards/<int:pk>/', CardViewSetD.as_view(), name='card')
]