from django.apps import AppConfig


class CardsConfig(AppConfig):
    name = 'cards'
