from django.shortcuts import render

# Create your views here.
from .models import Card
from .serializers import CardSerializer
from rest_framework import generics


class CardViewSet(generics.ListCreateAPIView):
    queryset = Card.objects.all()
    serializer_class = CardSerializer

class CardViewSetD(generics.RetrieveUpdateDestroyAPIView):
    queryset = Card.objects.all()
    serializer_class = CardSerializer
